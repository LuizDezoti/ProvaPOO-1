﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao1
{
    static class Questao1
    {
        static void Main(string[] args)
        {
           
            Console.WriteLine("Digite o nome completo:");
            string nomeCompleto = Console.ReadLine();

           
            NomeProprio nome = new NomeProprio(nomeCompleto);

            
            Console.WriteLine("Nome no formato acadêmico:");
            nome.ImprimeNomePaper();

            
            Console.ReadKey();
        }
    }
}